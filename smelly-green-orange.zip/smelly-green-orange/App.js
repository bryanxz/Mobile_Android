// Importa React e os componentes necessários do React Native
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
// Importa a classe Person que será utilizada no App
import Person from './Person';

// Define a classe principal App que extende de React.Component
export default class App extends React.Component {
  constructor(props) {
    super(props);
    // Cria instâncias de objetos da classe Person
    this.person1 = new Person('Lucas', 30, 'lucas@gmail.com', '123-564-234-12', '12-674.234', 'Breno', 'Bryan', '09/09/2024', '1234', 'Solteiro', 'Professor', 'Masculino');
    this.person2 = new Person('Cristiano', 28);
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Informações de Pessoas</Text>
        {/* Usa métodos da classe Person para exibir informações sobre a pessoa */}
        <Text style={styles.info}>{this.person1.getInfo()}</Text>
        <Text style={styles.info}>{this.person2.getInfo()}</Text>
      </View>
    );
  }
}

// Define os estilos para o componente App
const styles = StyleSheet.create({
  container: {
    flex: 1, // Faz a View preencher toda a tela
    justifyContent: 'center', // Centraliza o conteúdo verticalmente
    alignItems: 'center', // Centraliza o conteúdo horizontalmente
    backgroundColor: '#f0f0f0', // Define uma cor de fundo
  },
  title: {
    fontSize: 24, // Define o tamanho da fonte
    fontWeight: 'bold', // Define o peso da fonte
    marginBottom: 20, // Adiciona uma margem inferior
  },
  info: {
    fontSize: 18, // Define o tamanho da fonte para o texto
    color: '#333', // Define a cor do texto
    margin: 10, // Adiciona uma margem ao redor do texto
  },
});
