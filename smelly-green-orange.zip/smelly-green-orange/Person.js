// Define a classe Person para manipular informações sobre pessoas
export default class Person {
  // O construtor recebe o nome e a idade como parâmetros
  constructor(name, age, email, cpf, rg, nome_pai, nome_mae, aniversario, pis, estado_civil, profissao, sexo) {
    this.name = name; // Atributo nome
    this.age = age; // Atributo idade
    this.email = email;
    this.cpf = cpf;
    this.rg = rg;
    this.nome_pai = nome_pai;
    this.nome_mae = nome_mae;
    this.aniversario = aniversario;
    this.pis = pis;
    this.estado_civil - estado_civil;
    this.profissao = profissao;
    this.sexo = sexo;
  }

  // Método para retornar as informações da pessoa em formato de string
  getInfo() {
    return ` Nome: ${this.name}\n Email: ${this.email}\n Idade: ${this.age}\n CPF: ${this.cpf}\n RG: ${this.rg}\n Nome do Pai: ${this.nome_pai}\n Nome da Mae: ${this.nome_mae}\n Aniversario: ${this.aniversario}\n Carteira de Trabalho: ${this.pis}\n Estado Civil: ${this.estado_civil}\n Profissao: ${this.profissao}\n Sexo: ${this.sexo}`;
  }

  // Método para atualizar o nome da pessoa
  setName(newName) {
    this.name = newName; 
  }
  setAge(newAge) {
    this.age = newAge; 
  }
  setEmail(newemail) {
    this.email = newemail;
  }
  setCPF(newcpf) {
    this.cpf = newcpf;
  }
  setRG(newrg) {
    this.rg = newrg;
  }
  setNomepai(newnomepai) {
    this.nome_pai = newnomepai;
  }
  setNomeMae(newnomemae) {
    this.nome_mae = newnomemae;
  }
  setAniversario(newaniversario) {
    this.aniversario = newaniversario;
  }
  setPis(newpis) {
    this.pis = newpis; 
  }
  setEstadoCivil(newestadocivil) {
    this.estado_civil = newestadocivil;
  }
  setProfissao(newprofissao) {
    this.Profissao = newprofissao;
  }
  setSexo(newsexo) {
    this.sexo = newsexo;
  }
}
