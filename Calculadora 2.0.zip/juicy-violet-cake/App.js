import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, FlatList, ScrollView, Dimensions, Alert } from 'react-native';

export default function App() {
  const [currentInput, setCurrentInput] = useState('');
  const [previousInput, setPreviousInput] = useState('');
  const [operation, setOperation] = useState(null);
  const [history, setHistory] = useState([]); // Armazena o histórico de operações
  const [isResult, setIsResult] = useState(false); // Estado para identificar se o valor atual é um resultado

  const screenWidth = Dimensions.get('window').width;

  function handleInput(digit) {
    if (isResult) {
      setCurrentInput(digit);
      setIsResult(false);
    } else {
      setCurrentInput((prev) => prev + digit);
    }
  }

  function handleOperation(op) {
    if (currentInput === '' && op !== '√') return; // Não faz nada se o campo está vazio e a operação não é raiz quadrada
    if (previousInput !== '') {
      calculate(); // Calcula se já houver uma operação em andamento
    }
    setOperation(op);
    setPreviousInput(currentInput);
    setCurrentInput('');
    setIsResult(false);
  }

  function calculate() {
    if (operation == null || (currentInput === '' && operation !== '√')) return;

    const numCurrent = parseFloat(currentInput);
    const numPrevious = parseFloat(previousInput);
    let result = 0;
    let operationString = '';

    switch (operation) {
      case '+':
        result = numPrevious + numCurrent;
        operationString = `${numPrevious} + ${numCurrent} = ${result}`;
        break;
      case '-':
        result = numPrevious - numCurrent;
        operationString = `${numPrevious} - ${numCurrent} = ${result}`;
        break;
      case '*':
        result = numPrevious * numCurrent;
        operationString = `${numPrevious} * ${numCurrent} = ${result}`;
        break;
      case '/':
        if (numCurrent === 0) {
          Alert.alert("Erro", "Divisão por zero");
          return;
        }
        result = numPrevious / numCurrent;
        operationString = `${numPrevious} / ${numCurrent} = ${result}`;
        break;
      case '^':
        result = Math.pow(numPrevious, numCurrent);
        operationString = `${numPrevious} ^ ${numCurrent} = ${result}`;
        break;
      case '√':
        if (numPrevious < 0) {
          Alert.alert("Erro", "Raiz quadrada de número negativo");
          return;
        }
        result = Math.sqrt(numPrevious);
        operationString = `√${numPrevious} = ${result}`;
        break;
      case '%':
        result = (numPrevious * numCurrent) / 100;
        operationString = `${numPrevious} % ${numCurrent} = ${result}`;
        break;
      default:
        return;
    }

    setCurrentInput(String(result));
    setOperation(null);
    setPreviousInput('');
    setIsResult(true);

    // Atualiza o histórico com a operação completa
    setHistory((prevHistory) => {
      const newHistory = [{ key: Math.random().toString(), value: operationString }, ...prevHistory];
      return newHistory.slice(0, 5); // Mantém apenas os últimos 5 resultados
    });
  }

  function clearInput() {
    setCurrentInput('');
    setPreviousInput('');
    setOperation(null);
    setIsResult(false);
  }

  function deleteLast() {
    if (!isResult) {
      setCurrentInput((prev) => prev.slice(0, -1));
    }
  }

  function renderButton(digit, onPress) {
    return (
      <TouchableOpacity style={[styles.button, { width: screenWidth * 0.2 }]} onPress={() => onPress(digit)}>
        <Text style={styles.buttonText}>{digit}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <Text style={styles.result}>{currentInput || '0'}</Text>
        <View style={styles.row}>
          {['7', '8', '9', '/'].map(digit =>
            renderButton(digit, digit === '/' ? handleOperation : handleInput)
          )}
        </View>
        <View style={styles.row}>
          {['4', '5', '6', '*'].map(digit =>
            renderButton(digit, digit === '*' ? handleOperation : handleInput)
          )}
        </View>
        <View style={styles.row}>
          {['1', '2', '3', '-'].map(digit =>
            renderButton(digit, digit === '-' ? handleOperation : handleInput)
          )}
        </View>
        <View style={styles.row}>
          {['C', '0', '=', '+'].map(digit => {
            if (digit === 'C') return renderButton(digit, clearInput);
            if (digit === '=') return renderButton(digit, calculate);
            return renderButton(digit, digit === '+' ? handleOperation : handleInput);
          })}
        </View>
        <View style={styles.row}>
          {['^', '√', '%'].map(digit =>
            renderButton(digit, handleOperation)
          )}
        </View>

        {/* Exibe o histórico das últimas 5 operações em forma de lista */}
        <Text style={styles.historyHeader}>Últimos 5 Resultados:</Text>
        <FlatList
          style={styles.history}
          data={history}
          renderItem={({ item }) => (
            <View style={styles.listItem}>
              <Text>{item.value}</Text>
            </View>
          )}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
    width: '100%',
  },
  result: {
    fontSize: 40,
    color: 'black',
    margin: 20,
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 10,
  },
  button: {
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    margin: 10,
  },
  buttonText: {
    fontSize: 25,
  },
  historyHeader: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: 'bold',
  },
  history: {
    marginTop: 10,
    width: '100%',
  },
  listItem: {
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
  },
});
